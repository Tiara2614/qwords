<?php

namespace Database\Seeders;

use App\Models\Social;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SocialTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        try {
            DB::beginTransaction();

            $users = User::with('linktree')->get();
            $linktreesSocial = [];
            foreach ($users as $user) {
                if (!$user->linktree) {
                    continue;
                }

                $linktreeId = $user->linktree->id;
                $currentSocial = $user->linktree->socialmedia;
                if ($currentSocial && $currentSocial != 'null') {
                    foreach ($currentSocial as $key => $socials) {
                        if ($key === 'pinterest') {
                            continue;
                        }

                        $linktreesSocial[] = [
                            'linktree_id' => $linktreeId,
                            'name' => $key,
                            'url' => $socials,
                            'type' => 'default',
                            'created_at' => now(),
                            'updated_at' => now(),
                        ];
                    }
                }
            }

            Social::insert($linktreesSocial);

            DB::commit();
        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }
}
