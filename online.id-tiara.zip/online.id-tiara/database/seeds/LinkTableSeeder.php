<?php

namespace Database\Seeders;

use App\Models\Link;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LinkTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        try {
            DB::beginTransaction();

            $users = User::with('linktree')->get();
            $linktreesMyLink = [];
            foreach ($users as $user) {
                if (!$user->linktree) {
                    continue;
                }

                $linktreeId = $user->linktree->id;
                $currentLinks = $user->linktree->link;
                if ($currentLinks && $currentLinks != 'null') {
                    foreach ($currentLinks as $links) {
                        $linktreesMyLink[] = [
                            'linktree_id' => $linktreeId,
                            'title' => $links->title,
                            'url' => $links->url,
                            'created_at' => now(),
                            'updated_at' => now(),
                        ];
                    }
                }
            }

            Link::insert($linktreesMyLink);

            DB::commit();
        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }
}
