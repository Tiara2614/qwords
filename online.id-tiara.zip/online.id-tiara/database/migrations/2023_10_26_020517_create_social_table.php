<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSocialTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('socials', function (Blueprint $table) {
            $table->id();
            $table->integer('linktree_id')->nullable();
            $table->string('name', 191);
            $table->string('url', 255)->nullable();
            $table->string('type', 10)->default('default')->comment('default, custom');
            $table->string('icon', 191)->nullable();
            $table->string('icon_url', 255)->nullable();
            $table->timestamps();

            $table->foreign('linktree_id')->references('id')->on('linktrees')->onUpdate('cascade')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('socials');
    }
}
