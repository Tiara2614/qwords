<?php

namespace App\Src\Services\Whmcs;

class WHMCSService
{
    public function __construct()
    {
        if (env('APP_ENV') !== 'production') {
            $this->api_identifier = '8VQKxNBdSGt10mX3ViMloqFEnKS9PBjz';
            $this->api_secret = 'TH3JPI8ZHFkkLPNiMwNonZTLClx51Ve2';
            $this->base = 'https://stagingv8.portal.qwords.com';
        } else {
            $this->api_identifier = 'YAt3WSWBIoTtAS3n5dY0ESNu3csVnxUU';
            $this->api_secret = '9O1Y29mCYsJb8mrsjZS13gX5Kb3kVbG3';
            $this->base = 'https://portal.qwords.com/';
        }

    }

    public function request($post_data)
    {
        $post_data['username'] = $this->api_identifier;
        $post_data['password'] = $this->api_secret;
        $post_data['responsetype'] = 'json';

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $this->base . '/includes/api.php');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        $response = curl_exec($ch);

        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            \Log::error('CURL Error: ' . $error);
            return null;
        }

        curl_close($ch);
        return json_decode($response);
    }

}
