<?php

namespace App\Http\Controllers;

use App\Src\Services\Whmcs\WHMCSService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Dotenv\Validator;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\HttpFoundation\Session\Session;
use App\Models\User;
use Symfony\Component\HttpFoundation\Response;
use Socialite;
use Illuminate\Support\Facades\DB;

class AuthController extends Controller
{
    //
    public function __construct()
    {
        $this->whmcs = new WHMCSService();
    }


    public function register(){
        return view('register');
    }

    public function createUser(Request $request){
        $error=true;
        $alert='';
        $url='';
        $pesan='';
       // dd($request->all());
        $email = User::where('email',$request->email)->count();
        if($email > 0){
            $pesan.='<li>Email is already in use</li>';
        }

        if(empty($request->name)){
            $pesan.='<li>Name cannot be empty</li>';
        }

        if(empty($request->url)){
            $pesan.='<li>Url link Tree cannot be empty</li>';
        }
        if(empty($request->password)){
            $pesan.='<li>Password cannot be empty</li>';
        }else{
            if($request->password != $request->repassword ){
                $pesan.='<li>passwords are not the same</li>';
            }
        }

        if(!empty($pesan)){
            $alert='<ul>'.$pesan.'</ul>';
        }else{
            $user = new User;
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = Hash::make($request->password);
            $user->email_verified_at = \Carbon\Carbon::now();
            $user->url      = $request->url;
            $simpan = $user->save();
            if($simpan){
                $error=false;
                $alert='Registration is successful';
            }else{
                $alert='Registration failed';
            }
        }
      
        $respon=array(
            'error' => $error,
            'alert' => $alert,
            'url'   => $url
        );

        echo json_encode($respon);
      //  return Response::json($respon);
    }

    public function createUserQwords(Request $request){
        $error=true;
        $alert='';
        $url='';
        $pesan='';
      //  dd($request->all());
        $email = User::where('email',$request->email)->count();
       /*  if($email > 0){
            $pesan.='<li>Email is already in use</li>';
        } */

        $auth=$this->whmcs->request(['action' => 'ValidateLogin','email' => $request->email, 'password2' => $request->password ]);
        // dump($auth);
        // dump($auth->userid);
        if($auth->result == 'success' ){
            $client=$this->whmcs->request(['action' => 'GetClientsDetails','email' => $request->email ]);
// 			dd($client);
            $user = new User;
            $user->name = $client->firstname.' '.$client->lastname;
            $user->email = $client->email;
            $user->password = Hash::make($request->password);
            $user->email_verified_at = \Carbon\Carbon::now();
            $user->url      = $request->url;
            $user->google_id      = '';
            $simpan = $user->save(); 
            if($simpan){
				$data = User::find($user->id);
				Auth::login($data);
				
				
                $error=false;
				$url=url('/linkQ');
                $alert='Registration is successful';
            }else{
                $alert='Registration failed';
            }

        }else{
            $alert=$auth->message;
        }

        $respon=array(
            'error' => $error,
            'alert' => $alert,
            'url'   => $url
        );
        return response()->json($respon);
    }


    public function loginForm(){
        return view('login');
    }


    public function login(Request $request){
       // dd($request->all());
        $this->validate($request, [
            'email' => 'required',
            'password' => 'required',
        ]);
        $auth=$this->whmcs->request(['action' => 'ValidateLogin','email' => $request->email, 'password2' => $request->password ]);
      //  print_r($auth);
        $user = User::where('email', $request->email)->first();
        if($auth->result == 'success'){
            Auth::loginUsingId($user->id);
            return redirect('/linkQ');
        }else{
            return redirect()->route('loginform')
                ->with('error','Email-Address And Password Are Wrong.');
        }
    }



    public function logout(){
        Auth::logout();
        return redirect('/');
    }


    public function saveurl(Request $request){

        $error=true;
        $alert='';
        $isUser=Auth::user()->id;
        $url=DB::table('users')->where('url',$request->url)->first('url');
        //dd($request->all());
        if($request->url =='' ){
            $alert='Url tidak boleh kosong';
        }elseif(strlen($request->url) < 3 ){
            $alert='URL minimal 3 karakter maximal 10 karakter';
        }elseif(strlen($request->url) >= 10){
            $alert='URL minimal 3 karakter maximal 10 karakter';
        }elseif($url !=''){
            $alert='URL Sudah digunakan';
        }else{
            $update = DB::table('users')
            ->where('id', $isUser)
            ->update(
                [
                    'url'=> $request->url,
                ]
            );

            if($update){
                $error=false;
                $alert='url saved successfully';
            }else{
                $alert='url failed to save';
            }

        }

       
        $respon=array(
            'error' => $error,
            'alert' => $alert,
            'url'   =>  $request->url
        );
        return response()->json($respon);

    }




}
