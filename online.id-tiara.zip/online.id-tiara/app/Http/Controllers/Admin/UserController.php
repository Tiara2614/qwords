<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->get('search');

        $users = User::query()
            ->when($search, function($query) use ($search) {
                $query->where(function($q) use ($search) {
                    $q->where('name', 'like', "%{$search}%")
                      ->orWhere('email', 'like', "%{$search}%")
                      ->orWhere('role', 'like', "%{$search}%");
                });
            })
            ->latest()
            ->paginate(10);

        if ($request->ajax()) {
            return $users->isEmpty() ? '' : view('admin.users._table', compact('users', 'search'))->render();
        }

        return view('admin.users.index', compact('users', 'search'));
    }

    public function toggleAdmin(User $user)
    {
        if ($user->id === auth()->id()) {
            return redirect()->route('admin.users.index')
                ->with('error', 'Anda tidak dapat mengubah role Anda sendiri.');
        }

        if ($user->role === 'admin') {
            $user->role = 'client';
            $message = "Role admin untuk {$user->name} berhasil dicabut dan diubah menjadi client.";
        } else {
            $user->role = 'admin';
            $message = "User {$user->name} berhasil dijadikan admin.";
        }

        $user->save();

        return redirect()->route('admin.users.index')
            ->with('success', $message);
    }
}
