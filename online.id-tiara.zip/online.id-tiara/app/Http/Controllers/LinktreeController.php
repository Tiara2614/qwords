<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Dotenv\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class LinktreeController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index()
    {
        $isUser = Auth::user()->id;
        $url = DB::table('users')->where('id', $isUser)->first('url');
        $cek = DB::table('linktree')->where('user_id', $isUser)->first();
        //dd($cek);

		//client upgrade version_compare
		$is_Premium=true;

        $edit = false;
        if ($cek) {
            /* dd($cek); */
            $cek->link = json_decode($cek->link);
            $cek->socialmedia = json_decode($cek->socialmedia);
            $cek->linkcss = json_decode($cek->linkcss);
            return view('customlinkedit', ['data' => $cek, 'url' => $url->url, 'is_premium' => $is_Premium ]);
        } else {
            return view('customlink', ['url' => $url->url]);
        }
    }

    public function create(Request $request)
    {
        // dd($request->all());
        //  exit();
        $request->validate([
            'image'     => 'image|mimes:jpeg,png,jpg,gif|max:1024',
            'instagram' => 'required|min:3',
            'company'   => 'required|min:1',
        ]);


        if ($request->id) {

            $linktree = DB::table('linktree')->where('id', $request->id)->first();
            /*  dd($linktree); */
            $logo = $linktree->logo;
            if ($request->image) {
                $logo = time() . '.' . $request->image->extension();
                $request->image->move(public_path('assets/user/'), $logo);
            }

            // DB::enableQueryLog();
            $update = DB::table('linktree')
                ->where('id', $request->id)
                ->update(
                    [
                        'logo'          => $logo,
                        'instagram'     => $request->instagram,
                        'link'          => json_encode($request->link),
                        'company'       => $request->company,
                        'socialmedia'   => json_encode($request->sosial),
                        'background'    => $request->background,
                        'linkcss'        => json_encode($request->csslink)
                    ]
                );
            // dd($update);die();
            if ($update) {
                return redirect()->route('linktree')
                    ->with('success', 'linktree updated successfully');
            } else {
                return redirect()->route('linktree')
                    ->with('error', 'Error ');
            }
        } else {
            $imageName = '';
            if ($request->image) {
                $imageName = time() . '.' . $request->image->extension();
                $request->image->move(public_path('assets/user/'), $imageName);
            }

            $simpan = DB::table('linktree')->insert(
                array('logo' => $imageName,  'instagram' => $request->instagram, 'link' => json_encode($request->link), 'company' => $request->company, 'socialmedia' => json_encode($request->sosial), 'user_id' => Auth::user()->id)
            );

            if ($simpan) {
                return redirect('linkQ')
                    ->with('success', 'linktree saved successfully');
            } else {
                return redirect('linkQ')
                    ->with('error', 'Error ');
            }
        }
        // dd($simpan);
    }


    private function urlgenaret($length, $count = '1', $characters = 'lower_case,upper_case,numbers')
    {

        $symbols = array();
        $passwords = array();
        $used_symbols = '';
        $pass = '';
        // an array of different character types
        $symbols["lower_case"] = 'abcdefghijklmnopqrstuvwxyz';
        $symbols["upper_case"] = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $symbols["numbers"] = '1234567890';
        $symbols["special_symbols"] = '-';

        $characters = explode(",", $characters);
        foreach ($characters as $key => $value) {
            $used_symbols .= $symbols[$value];
        }
        $symbols_length = strlen($used_symbols) - 1;

        for ($p = 0; $p < $count; $p++) {
            $pass = '';
            for ($i = 0; $i < $length; $i++) {
                $n = rand(0, $symbols_length);
                $pass .= $used_symbols[$n];
            }
            $passwords[] = $pass;
        }

        if ($count == 1) {
            return $passwords[0];
        } else {
            return $passwords;
        }
    }


    public function publiclinktree($url)
    {
        $id = DB::table('users')->where('url', $url)->first('id');
        if (!$id) {
            return abort(404);
        }

        $data = DB::table('linktree')->where('user_id', $id->id)->first();

        if ($data) {
            $data->link = json_decode($data->link);
            $data->socialmedia = json_decode($data->socialmedia);
            $data->linkcss = json_decode($data->linkcss);
            if (Str::contains($data->instagram, 'https://instagram.com/')) {
                $data->instagram = str_replace('https://instagram.com/', '', $data->instagram);
            }
            if (Str::contains($data->instagram, '@')) {
                $data->instagram = str_replace('@', '', $data->instagram);
            }
            return view('linktree', ['data' =>  $data]);
        } else {
            return abort(404);
        }
    }
}
