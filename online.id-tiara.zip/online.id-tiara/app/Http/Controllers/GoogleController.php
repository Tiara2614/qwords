<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Socialite;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
class GoogleController extends Controller
{
    //
    public function redirect()
    {
        return Socialite::driver('google')->redirect();
    }

   
    public function callback()
    {
 
        if (Auth::check()) {
            return redirect('linkQ');
        }
 
        $oauthUser = Socialite::driver('google')->user();
		//dd($oauthUser);exit();
        $user = User::where('google_id', $oauthUser->id)->first();
        $email = User::where('email', $oauthUser->email)->first();
		
		if($email && !$user){
			return redirect()->route('loginform')
					->with('error','Email sudah terdaftar.');
		}
        if ($user) {
            Auth::loginUsingId($user->id);
            return redirect('linkQ');
        } else {
            /* $newUser = User::create([
                'name' => $oauthUser->name,
                'email' => $oauthUser->email,
                'google_id'=> $oauthUser->id,
                'password' => md5($oauthUser->id),
            ]); */
			
			
			
			
			$newUser =DB::table('users')->insertGetId(
				[
                'name' => $oauthUser->name,
                'email' => $oauthUser->email,
                'google_id'=> $oauthUser->id,
                'password' => Hash::make($oauthUser->id),
				]
			);
			$user = User::find($newUser);
            Auth::login($user);
            return redirect('linkQ');
        }
    }



}
