<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\MidtransService;
use Midtrans\Config;
use Midtrans\Snap;

class SnapMidtransController extends Controller
{
    protected $midtrans;

    public function __construct(MidtransService $midtrans)
    {
        $this->midtrans = $midtrans;
    }

    public function pay()
    {
        $order = [
            'order_id' => 'ORDER-' . uniqid(),
            'amount' => 50000, // Sesuai dengan harga premium
            'name' => auth()->user()->name,
            'email' => auth()->user()->email,
        ];

        $snapToken = $this->midtrans->createSnapToken($order);
        $clientKey = $this->midtrans->getClientKey();

        return view('paymentSnapMidtrans', compact('snapToken', 'clientKey'));
    }
}
