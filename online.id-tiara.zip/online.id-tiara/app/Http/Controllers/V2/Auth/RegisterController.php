<?php

namespace App\Http\Controllers\V2\Auth;

use App\Http\Controllers\Controller;
use App\Src\Services\Whmcs\WHMCSService;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class RegisterController extends Controller
{
    protected $whmcsApi;

    public function __construct()
    {
        $this->whmcsApi = new WHMCSService();
    }

    public function registerForm()
    {
        return view('auth.custom.register');
    }

    public function register(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email|unique:users,email',
                'password' => 'required|string',
                'url' => 'required|string|min:2|max:100|unique:users,url|regex:/^[0-9A-Za-z.\-_]+$/u',
            ], [
                'url.regex' => ':attribute hanya boleh berisi huruf, angka, strip, garis bawah dan titik.'
            ]);

            if ($validator->fails()) {
                return redirect()
                    ->back()
                    ->withErrors($validator)
                    ->withInput()
                    ->with('type', 'danger')
                    ->with('message', 'Invalid input');
            }

            $whmcsApi = $this->whmcsApi->request([
                'action' => 'ValidateLogin',
                'email' => $request->email,
                'password2' => $request->password,
            ]);

            if ($whmcsApi->result == 'success') {
                $client = $this->whmcsApi->request([
                    'action' => 'GetClientsDetails',
                    'email' => $request->email
                ]);

                $user = new User();
                $user->name = "{$client->firstname} {$client->lastname}";
                $user->email = $client->email;
                $user->password = Hash::make($request->password);
                $user->email_verified_at = \Carbon\Carbon::now();
                $user->url = $request->url;
                $user->google_id = '';
                $simpan = $user->save();

                if ($simpan) {
                    Auth::loginUsingId($user->id);
                    $alert = 'Registration is successfuly';
                } else {
                    $alert = 'Registration failed';
                }
            } else {
                throw new Exception($whmcsApi->message, 422);
            }

            return redirect()
                ->route('linktree')
                ->with('type', 'success')
                ->with('message', $alert);
        } catch (\Throwable $th) {
            return redirect()
                ->route('register')
                ->withInput()
                ->with('type', 'danger')
                ->with('message', $th->getMessage());
        }
    }

    public function registerPortal(Request $request) {
        try {
            $validator = Validator::make($request->all(), [
                'api_key' => 'required|in:286Vv71kGsjwYojrH1iNKWe8ItV9ALv,sjXlZAoOpLZEVKkVBsTmMdDmwSn0oLU',
                'email' => 'required|email|unique:users,email',
                'url' => 'required|string|min:2|max:100|unique:users,url|regex:/^[0-9A-Za-z.\-_]+$/u',
            ], [
                'url.regex' => ':attribute hanya boleh berisi huruf, angka, strip, garis bawah dan titik.',
                'api_key.in' => ':attribute tidak valid.'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid input',
                    'error' => $validator->errors(),
                ], 422);
            }

            $email = $request->email;
            $name = $request->name;
            $company = !empty($request->companyname) ? $request->companyname : "$request->name .Corp";
            $url = str_replace(' ', '', $request->url);

            $user = User::firstOrCreate(
                ['email' => $email],
                [
                    'name' => $name,
                    'email' => $email,
                    'password' => Hash::make(Str::random(8)),
                    'email_verified_at' => now(),
                    'url' => $url,
                    'google_id' => '',
                ],
            );

            if (!$user->linktree) {
                $user->linktree()->create([
                    'company' => $company,
                ]);
            }

            return response()->json([
                'success' => true,
                'message' => 'success',
                'data' => $user,
            ], 200);
        } catch (\Throwable $th) {
            return response()->json([
                'success' => false,
                'message' => $th->getMessage(),
                'error' => $th->getTraceAsString(),
            ], $th->getCode() > 0 ? $th->getCode() : 500);
        }
    }
}
