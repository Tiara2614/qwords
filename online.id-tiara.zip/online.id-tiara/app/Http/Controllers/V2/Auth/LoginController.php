<?php

namespace App\Http\Controllers\V2\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Src\Services\Whmcs\WHMCSService;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class LoginController extends Controller
{
    protected $whmcsApi;

    public function __construct()
    {
        $this->whmcsApi = new WHMCSService();
    }

    public function loginForm()
    {
        $linkqSso = env('APP_ENV') != 'production'
            ? 'https://stagingv8.portal.qwords.com/linkqSso.php?app_id=linkqreqsso_debug'
            : 'https://portal.qwords.com/linkqSso.php?app_id=linkqreqsso';

        return view('auth.custom.login', [
            'linkqSso' => $linkqSso,
        ]);
    }

    public function login(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => 'required|string',
            ]);

            if ($validator->fails()) {
                return redirect()
                    ->back()
                    ->withErrors($validator)
                    ->withInput()
                    ->with('type', 'danger')
                    ->with('message', 'Invalid input');
            }

            $whmcsApi = $this->whmcsApi->request([
                'action' => 'ValidateLogin',
                'email' => $request->email,
                'password2' => $request->password,
            ]);

            if (!is_object($whmcsApi) || !isset($whmcsApi->result) || $whmcsApi->result != 'success') {
                throw new Exception($whmcsApi->message ?? 'Failed to connect to WHMCS', 422);
            }

            $user = User::where('email', $request->email)->first();
            if (!$user) {
                throw new Exception('The user not exist', 422);
            }

            // Update last login time
            $user->last_login_at = now();
            $user->save();

            Auth::loginUsingId($user->id);

            $welcomeMessage = $user->isAdmin() ?
                "Welcome back, Admin {$user->name}!" :
                "Welcome back! {$user->name}";

            return redirect()
                ->route('linktree')
                ->with('type', 'success')
                ->with('message', $welcomeMessage);
        } catch (\Throwable $th) {
            return redirect()
                ->back()
                ->withInput()
                ->with('type', 'danger')
                ->with('message', $th->getMessage());
        }
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/');
    }

    function callbackWhmcs(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'sub' => 'required|string',
            ]);

            if ($validator->fails()) {
                session()->flash('type', 'danger');
                session()->flash('message', 'Invalid input');

                return view('auth.custom.callback.whmcs', [
                    'authorize' => false,
                ]);
            }

            $clientId = encryptDecryptFromWhmcs('decrypt', $request->sub);
            $whmcsApi = $this->whmcsApi->request([
                'action' => 'GetClientsDetails',
                'clientid' => $clientId,
            ]);

            if ($whmcsApi->result != 'success') {
                throw new Exception($whmcsApi->message, 422);
            }

            $email = $whmcsApi->email;
            $name = $whmcsApi->fullname;
            $company = !empty($whmcsApi->companyname) ? $whmcsApi->companyname : "$whmcsApi->fullname .Corp";
            $url = str_replace(' ', '', substr($name, 0, 4)) . "_" . Str::random(6);

            $user = User::firstOrCreate(
                ['email' => $email],
                [
                    'name' => $name,
                    'email' => $email,
                    'password' => Hash::make(Str::random(8)),
                    'email_verified_at' => now(),
                    'url' => $url,
                    'google_id' => '',
                    'role' => 'client', // Set default role as client
                    'last_login_at' => now() // Set initial login time
                ],
            );

            if (!$user->linktree) {
                $user->linktree()->create([
                    'company' => $company,
                ]);
            }

            // Update last login time for existing users
            if (!$user->wasRecentlyCreated) {
                $user->last_login_at = now();
                $user->save();
            }

            Auth::loginUsingId($user->id);

            $welcomeMessage = $user->isAdmin() ?
                "Welcome back, Admin {$user->name}!" :
                "Welcome back! {$user->name}";

            session()->flash('type', 'success');
            session()->flash('message', $welcomeMessage);

            return view('auth.custom.callback.whmcs', [
                'authorize' => true,
            ]);
        } catch (\Throwable $th) {
            session()->flash('type', 'danger');
            session()->flash('message', $th->getMessage());

            return view('auth.custom.callback.whmcs', [
                'authorize' => false,
            ]);
        }
    }
}
