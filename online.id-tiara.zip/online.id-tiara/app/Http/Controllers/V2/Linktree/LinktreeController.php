<?php

namespace App\Http\Controllers\V2\Linktree;

use App\Http\Controllers\Controller;
use App\Models\Link;
use App\Models\Social;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Kudashevs\ShareButtons\ShareButtons;
use Mews\Purifier\Facades\Purifier;
use Illuminate\Support\Facades\Log;
use App\Models\Invoice;
use PDF;

class LinktreeController extends Controller
{
    public function __construct()
    {
    }

    public function index(Request $request)
    {
        if (!$request->url) {
            $user = Auth::user();
        } else {
            $user = User::where('url', $request->url)->first();
        }

        if (!$user) {
            abort(404);
        }

        $myLink = User::with([
                        'linktree',
                        'linktree.links',
                        'linktree.socials' => function($q) {
                            return $q->orderBy('type', 'DESC');
                        }
                    ])->find($user->id);

        $url = $user->url;
        $myurl = url("/") ."/$url";
        $shareButton = new ShareButtons();
        $shareButton = $shareButton->page($myurl, ucwords($url) ." - Link-Q Share")
                            ->facebook()
                            ->twitter()
                            ->telegram()
                            ->whatsapp()
                            ->linkedin()
                            ->skype()
                            // ->copylink()
                            ->render();

        // TODO: gak tau buat apa
        $is_Premium = true;
        $mySocials = isset($myLink->linktree->socials) ? $myLink->linktree->socials->pluck('name') : [];
        if ($mySocials) {
            $mySocials = $mySocials->toArray();
        }

        $mode = $request->route()->getName() === 'linktree' ?  'edit' : 'view';

        //fetch api custom domain
        $customdomainurl = 'https://portal.qwords.com/apis/checkDomainLinkShare.php?email=' . $user->email ;
        $domainsData = file_get_contents($customdomainurl);
        $domains = json_decode($domainsData, true);

        return view('linktree.index', [
            'mode' => $mode,
            'myLink' => $myLink,
            'mySocials' => $mySocials,
            'url' => $user->url,
            'custom_domains' => $domains['data'],
            'domain' => $user->custom_domain,
            'myurl' => $myurl,
            'is_premium' => $is_Premium,
            'shareButton' => $shareButton,
            'email' => $user->email
        ]);
    }

    function manage(Request $request)
    {
        try {
            $section = $request->section;
            $user = Auth::user();
            $linktree = $user->linktree;

            // Check if user has active subscription for certain sections
            if (in_array($section, [
                'section.mylink', 
                'section.mylinkurl', 
                'section.logo',
                'section.tagline',
                'section.footer'
            ]) && !$user->hasActiveSubscription()) {
                return response()->json([
                    'success' => false,
                    'subscription_required' => true,
                    'message' => 'Anda memerlukan langganan premium untuk menggunakan fitur ini.'
                ], 403);
            }

            if (!$linktree) {
                $user->linktree()->create([
                    'company' => "$user->name Corp",
                ]);

                $user = User::with('linktree')->find($user->id);
                $linktree = $user->linktree;
            }

            $customMessage = '';
            $hasError = false;
            switch ($section) {
                case 'section.logo':
                    $validator = Validator::make($request->all(), [
                        'logo' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                    ]);

                    if ($hasError = $validator->fails()) {
                        break;
                    }

                    $logo = $request->logo;
                    $logoName = createFilename() . "." . $logo->extension();
                    $logoUrl = url('/') . "/assets/user/$logoName";
                    $request->logo->move(public_path("assets/user"), $logoName);

                    $linktree->logo = $logoName;
                    $linktree->logo_url = $logoUrl;
                    $linktree->save();

                    $customMessage = __('The logo updated successfully!');

                    break;
                case 'section.tagline':
                    $validator = Validator::make($request->all(), [
                        'tagline' => 'string|required',
                    ]);

                    if ($hasError = $validator->fails()) {
                        break;
                    }

                    $linktree->tagline = Purifier::clean($request->tagline);
                    $linktree->save();

                    $customMessage = __('The tagline updated successfully!');

                    break;
                case 'section.footer':
                    $validator = Validator::make($request->all(), [
                        'ig' => 'string|required|max:191',
                        'company' => 'string|required|max:255',
                    ]);

                    if ($hasError = $validator->fails()) {
                        break;
                    }

                    $linktree->instagram = $request->ig;
                    $linktree->company = $request->company;
                    $linktree->save();

                    $customMessage = __('The intagram & company updated successfully!');

                    break;
                case 'section.mylink':
                    $validator = Validator::make($request->all(), [
                        'title' => 'string|required|max:191',
                        'url' => 'string|url|required',
                        'custom_icon' => 'nullable|image|mimes:jpeg,png,jpg,svg|max:500',
                    ]);

                    if ($hasError = $validator->fails()) {
                        break;
                    }

                    $icon = $request->custom_icon;
                    $iconData = [];
                    if ($icon) {
                        $iconName = createFilename() . "." . $icon->extension();
                        $iconUrl = url('/') . "/assets/user/mylink/custom_icon/$iconName";
                        $icon->move(public_path("assets/user/mylink/custom_icon"), $iconName);

                        $iconData = [
                            'icon_name' => $iconName,
                            'icon_url' => $iconUrl,
                        ];
                    }

                    $linktree->links()->create(array_merge([
                        'title' => $request->title,
                        'url' => $request->url,
                    ], $iconData));

                    $customMessage = __('The link updated successfully!');
                    break;
                case 'section.social':
                    $validator = Validator::make($request->all(), [
                        'type' => 'string|required|in:default,custom',
                        'default_icon' => 'nullable|string|in:shopee.png,tokopedia.png,lazada.png,blibli.png',
                        'name' => 'string|required|max:191',
                        'url' => 'string|url|required|max:255',
                        'icon' => 'nullable|image|mimes:jpeg,png,jpg,svg|max:1024',
                    ]);

                    if ($hasError = $validator->fails()) {
                        break;
                    }

                    $iconName = null;
                    $iconUrl = null;
                    $icon = $request->icon;
                    $defaultIcon = $request->default_icon;
                    $iconData = [];
                    if ($icon) {
                        $iconName = createFilename() . "." . $icon->extension();
                        $iconUrl = url('/') . "/assets/user/social/logo/$iconName";
                        $icon->move(public_path("assets/user/social/logo"), $iconName);

                        $iconData = [
                            'icon_url' => $iconUrl,
                            'type' => $request->type,
                        ];
                    } else if ($defaultIcon) {
                        $iconData = [
                            'icon_url' => asset("assets/img/ecommerce/$defaultIcon"),
                            'type' => $request->type,
                        ];
                    }

                    $linktree->socials()->updateOrCreate(
                        ['name' => strtolower($request->name)],
                        array_merge([
                            // 'name' => strtolower($request->name),
                            'url' => $request->url,
                            'icon' => $iconName,
                        ], $iconData),
                    );

                    $customMessage = __('The social link updated successfully!');
                    break;
                case 'section.mylinkurl':
                    $validator = Validator::make($request->all(), [
                        'mylinkurl' => 'required|string|min:2|max:100|unique:users,url,' .$user->id .'|regex:/^[0-9A-Za-z.\-_]+$/u',
                    ], [
                        'regex' => ':attribute hanya boleh berisi huruf, angka, strip, garis bawah dan titik.'
                    ]);

                    if ($hasError = $validator->fails()) {
                        break;
                    }

                    $user->url = $request->mylinkurl;
                    $user->save();

                    //kondisi untuk membuat file di dns manager
                    if($request->custom_domain !== "online.id"){
                        $customdomainurl = 'https://portal.qwords.com/apis/checkDomainLinkShare.php?email=' . $user->email ;
                        $domainsData = file_get_contents($customdomainurl);

                        if ($domainsData !== false) {
                            Log::info('Data domain user in dns manager', ['data' => $domainsData]);
                        } else {
                            Log::error('Failed to retrieve data from the DNS manager.');
                        }

                        $domains = json_decode($domainsData, true);
                        $domainFound = false;

                        foreach ($domains['data'] as $domain) {
                            if ($domain['domain'] === $request->custom_domain) {
                                $domainFound = true;
                                break;
                            }
                        }

                        if (!$domainFound) {
                            return redirect()
                                ->back()
                                ->withInput()
                                ->with('type', 'danger')
                                ->with('message', 'custom domain tidak ditemukan!');
                        }

                        $checkWhois = 'https://qwords.com/apis/find.php?domain=' . $request->custom_domain ;
                        $whoisData  = file_get_contents($checkWhois);
                        if ($whoisData !== false) {
                            Log::info('WHOIS data for domain', ['domain' => $request->custom_domain, 'data' => $whoisData]);
                        } else {
                            Log::error('Failed to retrieve WHOIS data for domain: ' . $request->custom_domain);
                        }
                        $whoisResult = json_decode($whoisData , true);

                        if ($whoisResult['status'] === "available") {
                            return redirect()
                                ->back()
                                ->withInput()
                                ->with('type', 'danger')
                                ->with('message', 'domain tidak dapat diredirect!');
                        }
                        $user->custom_domain = $request->custom_domain;
                        $user->save();

                        // Target URL for the POST request
                        $targetUrl = 'http://dnsmanager.my.id/domain-forward/forward-domain.php?action=forwarddomain&domain=' . $request->custom_domain . '&target=https://online.id/' . $request->mylinkurl;
                        $forwardDomainData = file_get_contents($targetUrl);

                        if ($forwardDomainData !== false) {
                            Log::info('Forward domain response', ['domain' => $request->custom_domain, 'data' => $forwardDomainData]);
                        } else {
                            Log::error('Failed to forward domain: ' . $request->custom_domain);
                        }
                        $resultForward = json_decode($forwardDomainData, true);
                        if ($resultForward !== null) {
                            $code = $resultForward['status'];

                            if($code){
                                $customMessage = __('The link url updated successfully!');
                                return redirect()
                                ->back()
                                ->with('type', 'success')
                                ->with('message', $customMessage);
                            }else{
                                return redirect()
                                    ->back()
                                    ->withInput()
                                    ->with('type', 'danger')
                                    ->with('message', "Error update link");
                            }
                        }else{
                            return redirect()
                                ->back()
                                ->withInput()
                                ->with('type', 'danger')
                                ->with('message', "Error update link");
                        }
                    }else{
                        $customMessage = __('The link url updated successfully!');
                    }
                    break;
                default:
                    return redirect()
                        ->back()
                        ->with('type', 'danger')
                        ->with('message', 'Undefined section!');
                    break;
            }

            if ($hasError) {
                return redirect()
                    ->back()
                    ->withErrors($validator)
                    ->withInput()
                    ->with('type', 'danger')
                    ->with('message', 'Invalid input');
            }

            return redirect()
                ->back()
                ->with('type', 'success')
                ->with('message', "Well done! $customMessage");
        } catch (\Throwable $th) {
            return redirect()
                ->back()
                ->withInput()
                ->with('type', 'danger')
                ->with('message', $th->getMessage());
        }
    }

    function updateMyLink(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'id' => 'numeric|required|exists:links,id',
                'title' => 'string|required|max:191',
                'url' => 'string|url|required',
                'custom_icon' => 'nullable|image|mimes:jpeg,png,jpg,svg|max:500',
            ]);

            if ($validator->fails()) {
                return redirect()
                    ->back()
                    ->withErrors($validator)
                    ->withInput()
                    ->with('type', 'danger')
                    ->with('message', 'Invalid input');
            }

            $icon = $request->custom_icon;
            $iconData = [];
            if ($icon) {
                $iconName = createFilename() . "." . $icon->extension();
                $iconUrl = url('/') . "/assets/user/mylink/custom_icon/$iconName";
                $icon->move(public_path("assets/user/mylink/custom_icon"), $iconName);

                $iconData = [
                    'icon_name' => $iconName,
                    'icon_url' => $iconUrl,
                ];
            }

            $myLink = Link::find($request->id);
            $myLink->title = $request->title;
            $myLink->url = $request->url;
            if ($iconData) {
                $myLink->icon_name = $iconData['icon_name'];
                $myLink->icon_url = $iconData['icon_url'];
            }

            $myLink->save();

            return redirect()
                ->back()
                ->with('type', 'success')
                ->with('message', "Well done! The link updated successfully");
        } catch (\Throwable $th) {
            return redirect()
                ->back()
                ->withInput()
                ->with('type', 'danger')
                ->with('message', $th->getMessage());
        }
    }

    function deleteMyLink(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'id' => 'numeric|required|exists:links,id',
            ]);

            if ($validator->fails()) {
                return redirect()
                    ->back()
                    ->withErrors($validator)
                    ->withInput()
                    ->with('type', 'danger')
                    ->with('message', 'Invalid input');
            }

            $myLink = Link::find($request->id);
            $myLink->delete();

            return redirect()
                ->back()
                ->with('type', 'success')
                ->with('message', "Well done! The link deleted successfully");
        } catch (\Throwable $th) {
            return redirect()
                ->back()
                ->withInput()
                ->with('type', 'danger')
                ->with('message', $th->getMessage());
        }
    }

    function deleteSocial(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'id' => 'numeric|required|exists:socials,id',
            ]);

            if ($validator->fails()) {
                return redirect()
                    ->back()
                    ->withErrors($validator)
                    ->withInput()
                    ->with('type', 'danger')
                    ->with('message', 'Invalid input');
            }

            $social = Social::find($request->id);
            $social->delete();

            return redirect()
                ->back()
                ->with('type', 'success')
                ->with('message', "Well done! The social link deleted successfully");
        } catch (\Throwable $th) {
            return redirect()
                ->back()
                ->withInput()
                ->with('type', 'danger')
                ->with('message', $th->getMessage());
        }
    }

    public function checkClaim(Request $request) {
        try {
            $validator = Validator::make(['claim' => $request->claim], [
                'claim' => 'required|string',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid input',
                    'error' => $validator->errors(),
                ], 422);
            }

            $user = User::where('url', $request->claim)->count();
            return response()->json([
                'success' => true,
                'message' => 'success',
                'data' => [
                    'available' => !$user,
                ],
            ], 200);
        } catch (\Throwable $th) {
            return response()->json([
                'success' => false,
                'message' => $th->getMessage(),
                'error' => $th->getTraceAsString(),
            ], $th->getCode() > 0 ? $th->getCode() : 500);
        }
    }

    public function checkExist(Request $request) {
        try {
            $validator = Validator::make(['email' => $request->email], [
                'email' => 'required|string|email',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid input',
                    'error' => $validator->errors(),
                ], 422);
            }

            $user = User::where('email', $request->email)->count();
            return response()->json([
                'success' => true,
                'message' => 'success',
                'data' => [
                    'exist' => $user > 0,
                ],
            ], 200);
        } catch (\Throwable $th) {
            return response()->json([
                'success' => false,
                'message' => $th->getMessage(),
                'error' => $th->getTraceAsString(),
            ], $th->getCode() > 0 ? $th->getCode() : 500);
        }
    }

    public function upgradeProduct(Request $request)
    {
        $user = Auth::user();
        if (!$user) {
            return redirect()->route('login.form');
        }

        $myLink = User::with([
            'linktree',
            'linktree.links',
            'linktree.socials' => function($q) {
                return $q->orderBy('type', 'DESC');
            }
        ])->find($user->id);

        if (!$myLink->linktree) {
            return redirect()->route('linktree')->with('error', 'Please create your linktree first');
        }

        return view('upgrade', [
            'myLink' => $myLink,
            'url' => $user->url,
            'email' => $user->email,
        ]);
    }

    public function premiumProduct(Request $request)
    {
        $user = Auth::user();
        if (!$user) {
            return redirect()->route('login.form');
        }

        $myLink = User::with([
            'linktree',
            'linktree.links',
            'linktree.socials' => function($q) {
                return $q->orderBy('type', 'DESC');
            }
        ])->find($user->id);

        if (!$myLink->linktree) {
            return redirect()->route('linktree')->with('error', 'Please create your linktree first');
        }

        return view('premium', [
            'myLink' => $myLink,
            'url' => $user->url,
            'email' => $user->email,
        ]);
    }

    public function invoices(Request $request)
    {
        $user = Auth::user();
        if (!$user) {
            return redirect()->route('login');
        }

        $perPage = $request->get('per_page', 10);
        $perPage = in_array($perPage, [10, 25, 50]) ? $perPage : 10;

        $invoices = Invoice::where('user_id', $user->id)
                          ->orderBy('created_at', 'desc')
                          ->paginate($perPage);

        return view('invoices', compact('invoices'));
    }

    public function payment()
    {
        $user = Auth::user();
        if (!$user) {
            abort(404);
        }

        // Fetch all Midtrans settings
        $settings = DB::table('generalsettings')
            ->whereIn('setting', ['midtrans_client_key', 'midtrans_server_key', 'midtrans_is_production'])
            ->get()
            ->pluck('value', 'setting');

        // Debug the settings
        Log::info('Settings from database:', [
            'settings' => $settings,
            'as_array' => $settings->toArray()
        ]);

        // Convert settings to object for view compatibility
        $settingsObj = (object)[
            'midtrans_client_key' => $settings['midtrans_client_key'],
            'midtrans_server_key' => $settings['midtrans_server_key'],
            'midtrans_is_production' => true
        ];

        // Dummy order data
        $order = [
            'id' => 'ORDER Link-Q -' . time(),
            'amount' => 1000,
            'description' => 'Premium Plan Subscription - Monthly'
        ];

        return view('payment', [
            'order' => $order,
            'user' => $user,
            'settings' => $settingsObj
        ]);
    }

    public function processPayment(Request $request)
    {
        try {
            $user = Auth::user();
            if (!$user) {
                Log::error('Unauthorized payment attempt');
                return response()->json(['error' => 'User tidak terautentikasi'], 401);
            }

            // Generate invoice number using the model method
            $invoiceNumber = (new Invoice)->generateInvoiceNumber();
            $orderId = 'ORDER-' . time() . '-' . $user->id;
            $amount = 1000;
            $description = 'Berlangganan Paket Premium - Bulanan';

            Log::info('Creating invoice', [
                'user_id' => $user->id,
                'invoice_number' => $invoiceNumber,
                'amount' => $amount
            ]);

            // Create invoice record
            $invoice = Invoice::create([
                'user_id' => $user->id,
                'invoice_number' => $invoiceNumber,
                'amount' => $amount,
                'description' => $description,
                'status' => 'pending',
                'order_id' => $orderId
            ]);

            // Fetch Midtrans settings
            $settings = DB::table('generalsettings')
                ->whereIn('setting', ['midtrans_client_key', 'midtrans_server_key', 'midtrans_is_production'])
                ->get()
                ->pluck('value', 'setting');

            if (empty($settings['midtrans_server_key'])) {
                Log::error('Midtrans server key not found in settings', ['available_settings' => $settings]);
                throw new \Exception('Konfigurasi pembayaran tidak lengkap: Server key tidak ditemukan');
            }

            // Set Midtrans configuration
            \Midtrans\Config::$serverKey = $settings['midtrans_server_key'];
            \Midtrans\Config::$isProduction = false; // Gunakan sandbox mode untuk testing
            \Midtrans\Config::$isSanitized = true;
            \Midtrans\Config::$is3ds = true;

            // Log configuration for debugging
            Log::info('Using Midtrans Configuration', [
                'server_key_exists' => !empty($settings['midtrans_server_key']),
                'server_key_length' => strlen($settings['midtrans_server_key']),
                'is_production' => false
            ]);

            $params = array(
                'transaction_details' => array(
                    'order_id' => $orderId,
                    'gross_amount' => $amount,
                ),
                'customer_details' => array(
                    'first_name' => $user->name,
                    'email' => $user->email,
                ),
                'item_details' => array(
                    [
                        'id' => 'PREMIUM1',
                        'price' => $amount,
                        'quantity' => 1,
                        'name' => $description
                    ]
                )
            );

            Log::info('Requesting Midtrans snap token', [
                'order_id' => $orderId,
                'amount' => $amount
            ]);

            $snapToken = \Midtrans\Snap::getSnapToken($params);
            
            // Update invoice with snap token
            $invoice->update([
                'snap_token' => $snapToken
            ]);

            Log::info('Payment process successful', [
                'invoice_id' => $invoice->id,
                'snap_token' => $snapToken
            ]);

            // Return both snap token and invoice ID
            return response()->json([
                'success' => true,
                'snap_token' => $snapToken,
                'invoice_id' => $invoice->id,
                'redirect_url' => route('invoice.new', ['id' => $invoice->id])
            ]);

        } catch (\Exception $e) {
            Log::error('Payment Processing Error: ' . $e->getMessage(), [
                'user_id' => Auth::id(),
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Terjadi kesalahan dalam pemrosesan pembayaran: ' . $e->getMessage()
            ], 500);
        }
    }

    public function showInvoice($id)
    {
        try {
            $user = Auth::user();
            if (!$user) {
                return redirect()->route('login');
            }

            $invoice = Invoice::where('id', $id)
                            ->where('user_id', $user->id)
                            ->firstOrFail();

            // Fetch Midtrans settings
            $settings = DB::table('generalsettings')
                ->whereIn('setting', ['midtrans_client_key', 'midtrans_server_key', 'midtrans_is_production'])
                ->get()
                ->pluck('value', 'setting');

            $settingsObj = (object)[
                'midtrans_client_key' => $settings['midtrans_client_key'] ?? null,
                'midtrans_server_key' => $settings['midtrans_server_key'] ?? null,
                'midtrans_is_production' => false // Force false for local development
            ];

            return view('client.invoices.show', [
                'invoice' => $invoice,
                'user' => $user,
                'client_key' => $settingsObj->midtrans_client_key,
                'settings' => $settingsObj
            ]);

        } catch (\Exception $e) {
            Log::error('Error showing invoice: ' . $e->getMessage(), [
                'invoice_id' => $id,
                'user_id' => Auth::id(),
                'error' => $e->getMessage()
            ]);

            return redirect()->route('client.invoices.index')
                           ->with('error', 'Invoice tidak ditemukan');
        }
    }

    public function showNewInvoice($id)
    {
        try {
            $user = Auth::user();
            if (!$user) {
                return redirect()->route('login');
            }

            $invoice = Invoice::where('id', $id)
                            ->where('user_id', $user->id)
                            ->firstOrFail();

            // Fetch Midtrans settings
            $settings = DB::table('generalsettings')
                ->whereIn('setting', ['midtrans_client_key', 'midtrans_server_key', 'midtrans_is_production'])
                ->get()
                ->pluck('value', 'setting');

            $settingsObj = (object)[
                'midtrans_client_key' => $settings['midtrans_client_key'] ?? null,
                'midtrans_server_key' => $settings['midtrans_server_key'] ?? null,
                'midtrans_is_production' => false // Force false for local development
            ];

            return view('invoice-new', [
                'invoice' => $invoice,
                'user' => $user,
                'client_key' => $settingsObj->midtrans_client_key,
                'settings' => $settingsObj
            ]);

        } catch (\Exception $e) {
            Log::error('Error showing invoice: ' . $e->getMessage(), [
                'invoice_id' => $id,
                'user_id' => Auth::id(),
                'error' => $e->getMessage()
            ]);

            return redirect()->route('client.invoices.index')
                           ->with('error', 'Invoice tidak ditemukan');
        }
    }

    public function payInvoice($id)
    {
        try {
            $user = Auth::user();
            if (!$user) {
                return response()->json(['error' => 'User tidak terautentikasi'], 401);
            }

            $invoice = Invoice::where('id', $id)
                            ->where('user_id', $user->id)
                            ->firstOrFail();

            if ($invoice->status === 'paid') {
                return response()->json(['error' => 'Invoice sudah dibayar'], 400);
            }

            // Generate order_id jika belum ada
            if (!$invoice->order_id) {
                $order_id = 'INV-' . time() . '-' . $user->id . '-' . $invoice->id;
                $invoice->update(['order_id' => $order_id]);
            } else {
                // Jika order_id sudah ada, generate yang baru dengan timestamp untuk memastikan unik
                $order_id = $invoice->order_id . '-' . time();
            }

            // Fetch Midtrans settings
            $settings = DB::table('generalsettings')
                ->whereIn('setting', ['midtrans_client_key', 'midtrans_server_key', 'midtrans_is_production'])
                ->get()
                ->pluck('value', 'setting');

            if (empty($settings['midtrans_server_key'])) {
                Log::error('Midtrans server key not found');
                throw new \Exception('Konfigurasi pembayaran tidak lengkap');
            }

            // Set Midtrans configuration
            \Midtrans\Config::$serverKey = $settings['midtrans_server_key'];
            \Midtrans\Config::$isProduction = false;
            \Midtrans\Config::$isSanitized = true;
            \Midtrans\Config::$is3ds = true;

            $params = array(
                'transaction_details' => array(
                    'order_id' => $order_id,
                    'gross_amount' => (int)$invoice->amount,
                ),
                'customer_details' => array(
                    'first_name' => $user->name,
                    'email' => $user->email,
                ),
                'item_details' => array(
                    [
                        'id' => 'PREMIUM1',
                        'price' => (int)$invoice->amount,
                        'quantity' => 1,
                        'name' => $invoice->description
                    ]
                )
            );

            Log::info('Requesting Midtrans snap token for invoice payment', [
                'invoice_id' => $invoice->id,
                'order_id' => $order_id,
                'amount' => $invoice->amount
            ]);

            $snapToken = \Midtrans\Snap::getSnapToken($params);
            
            // Update invoice with snap token
            $invoice->update([
                'snap_token' => $snapToken
            ]);

            Log::info('Payment process successful', [
                'invoice_id' => $invoice->id,
                'snap_token' => $snapToken
            ]);

            return response()->json([
                'success' => true,
                'snap_token' => $snapToken
            ]);

        } catch (\Exception $e) {
            Log::error('Payment Processing Error: ' . $e->getMessage(), [
                'invoice_id' => $id,
                'user_id' => Auth::id(),
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'success' => false,
                'error' => 'Terjadi kesalahan dalam pemrosesan pembayaran: ' . $e->getMessage()
            ], 500);
        }
    }

    public function downloadInvoice($id)
    {
        try {
            $user = Auth::user();
            if (!$user) {
                return redirect()->route('login');
            }

            $invoice = Invoice::where('id', $id)
                            ->where('user_id', $user->id)
                            ->firstOrFail();

            $pdf = PDF::loadView('invoice-pdf', [
                'invoice' => $invoice,
                'user' => $user
            ]);

            $filename = 'Invoice-' . $invoice->invoice_number . '.pdf';
            
            return $pdf->download($filename);

        } catch (\Exception $e) {
            Log::error('Error downloading invoice: ' . $e->getMessage(), [
                'invoice_id' => $id,
                'user_id' => Auth::id(),
                'error' => $e->getMessage()
            ]);

            return redirect()->route('client.invoices.index')
                           ->with('error', 'Gagal mengunduh invoice');
        }
    }

    public function handleMidtransNotification(Request $request)
    {
        try {
            $notification = new \Midtrans\Notification();

            $transaction = $notification->transaction_status;
            $type = $notification->payment_type;
            $order_id = $notification->order_id;
            $fraud = $notification->fraud_status;

            Log::info('Midtrans Notification', [
                'order_id' => $order_id,
                'transaction_status' => $transaction,
                'payment_type' => $type,
                'fraud_status' => $fraud
            ]);

            $invoice = Invoice::where('order_id', $order_id)->firstOrFail();

            if ($transaction == 'capture') {
                if ($type == 'credit_card') {
                    if($fraud == 'challenge') {
                        $invoice->status = 'pending';
                    } else {
                        $invoice->status = 'paid';
                        $invoice->paid_at = now();
                    }
                }
            }
            else if ($transaction == 'settlement') {
                $invoice->status = 'paid';
                $invoice->paid_at = now();
            }
            else if($transaction == 'pending') {
                $invoice->status = 'pending';
            }
            else if ($transaction == 'deny') {
                $invoice->status = 'unpaid';
            }
            else if ($transaction == 'expire') {
                $invoice->status = 'unpaid';
            }
            else if ($transaction == 'cancel') {
                $invoice->status = 'unpaid';
            }

            // Simpan detail pembayaran
            $invoice->payment_details = json_encode([
                'payment_type' => $type,
                'transaction_id' => $notification->transaction_id,
                'transaction_time' => $notification->transaction_time,
                'transaction_status' => $transaction,
                'bank' => $notification->bank ?? null,
                'va_number' => $notification->va_numbers[0]->va_number ?? null,
                'fraud_status' => $fraud ?? null
            ]);

            $invoice->save();

            // Jika pembayaran sukses, update subscription user
            if ($invoice->status === 'paid') {
                $user = $invoice->user;
                // Tambahkan logika untuk mengupdate subscription user di sini
                // Contoh:
                // $user->subscription()->create([
                //     'start_date' => now(),
                //     'end_date' => now()->addMonth(),
                //     'status' => 'active'
                // ]);
            }

            return response()->json(['status' => 'success']);

        } catch (\Exception $e) {
            Log::error('Midtrans Notification Error: ' . $e->getMessage(), [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage()
            ], 500);
        }
    }
}
