<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Midtrans\Config;
use Midtrans\Snap;

class MidtransService
{
    public function __construct()
    {
        // Set konfigurasi midtrans
        Config::$serverKey = 'SB-Mid-server-_xxxxxxxxxxxxxxxx'; // Ganti dengan Server Key anda
        Config::$clientKey = 'SB-Mid-client-_xxxxxxxxxxxxxxxx'; // Ganti dengan Client Key anda
        Config::$isProduction = false;
        Config::$isSanitized = true;
        Config::$is3ds = true;
    }

    public function createSnapToken(array $order): string
    {
        $params = [
            'transaction_details' => [
                'order_id' => $order['order_id'],
                'gross_amount' => $order['amount'],
            ],
            'customer_details' => [
                'first_name' => $order['name'],
                'email' => $order['email'],
            ],
        ];

        return Snap::getSnapToken($params);
    }

    public function getClientKey(): string
    {
        return Config::$clientKey;
    }
}
