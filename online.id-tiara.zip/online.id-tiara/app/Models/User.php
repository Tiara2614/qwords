<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Laravel\Sanctum\HasApiTokens;
use App\Models\Invoice;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable, HasFactory;

    public $guarded = false;

    protected $table = 'users';

    protected $fillable = [
        'name',
        'email',
        'password',
        'url',
        'role',
        'is_premium',
        'phone',
        'last_login_at'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'last_login_at' => 'datetime',
        'is_premium' => 'boolean',
    ];

    function linktree()
    {
        return $this->hasOne(Linktree::class);
    }

    public function isAdmin()
    {
        return $this->role === 'admin';
    }

    public function hasActiveSubscription()
    {
        return Invoice::where('user_id', $this->id)
            ->where('status', 'paid')
            ->where('created_at', '>=', now()->subDays(30))
            ->exists();
    }
}
