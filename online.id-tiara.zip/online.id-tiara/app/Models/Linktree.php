<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Linktree extends Model
{
    use HasFactory;

    protected $table = 'linktrees';
    public $timestamps = false;
    public $guarded = false;

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'link' => 'object',
        'socialmedia' => 'object',
        'linkcss' => 'object',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function links()
    {
        return $this->hasMany(Link::class, 'linktree_id');
    }

    public function socials()
    {
        return $this->hasMany(Social::class, 'linktree_id');
    }
}
